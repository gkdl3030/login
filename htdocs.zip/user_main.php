<?php
    echo "<br><br><center><h2> o 회원 관리 프로젝트 o </h2><hr>";
    echo "<br><br> ~ 회원 관리 프로그램을 가동합니다. ~ <br>";
    echo "<br><br><font size=4> ->>> 이동할 화면을 선택하십시오. <<<- <br><br><br></font>";
    echo "🧩🧩 &nbsp;[ <a href=login_form.php> 로그인</a> ] &nbsp;&nbsp; ";
    echo " | &nbsp;&nbsp; [ <a href=add_form.php> 회원 가입 </a> ]&nbsp; 🧩🧩 </center>";
?>